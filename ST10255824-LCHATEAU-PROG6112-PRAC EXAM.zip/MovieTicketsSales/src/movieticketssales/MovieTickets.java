/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package movieticketssales;

 interface IMovieTickets {
    
    int TotalMovieSales(int[] movieTicketSales);
    String TopMovie(String[] movies, int[] totalSales);
}
public class MovieTickets implements IMovieTickets {
   
    // Method to calculate the total ticket sales for a movie
    @Override
    public int TotalMovieSales(int[] movieTicketSales) {
        int total = 0;
        for (int sales : movieTicketSales) {
            total += sales;
        }
        return total;
    }

    // Method to determine the top-performing movie
    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        int maxSales = totalSales[0];
        String topMovie = movies[0];
         //https://www.w3schools.com/java/java_arrays_loop.asp used to help with looping through arrays
        for (int i = 1; i < movies.length; i++) {
            if (totalSales[i] > maxSales) {
                maxSales = totalSales[i];
                topMovie = movies[i];
            }
        }
        return topMovie;
        //https://www.guru99.com/java-swing-gui.html used to help code up GUI
//https://www3.ntu.edu.sg/home/ehchua/programming/java/j4a_gui.html used to help code up GUI
    

    }
}




