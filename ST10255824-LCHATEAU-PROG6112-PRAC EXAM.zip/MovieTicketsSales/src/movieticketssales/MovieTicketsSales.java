/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package movieticketssales;

/**
 *
 * @author lab_services_student
 */
public class MovieTicketsSales {

  public static void main(String[] args) {
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[][] ticketSales = {
            {3000, 1500, 1700}, // Napoleon's sales for Jan, Feb, Mar
            {3500, 1200, 1600}  // Oppenheimer's sales for Jan, Feb, Mar
        };
        //https://www.w3schools.com/java/java_arrays.asp used to help with arrays
       
        MovieTickets movieTickets = new MovieTickets();
        int[] totalSales = new int[movies.length];
       
        System.out.println("MOVIE TICKET SALES REPORT - 2024");
       
        System.out.println("          JAN    FEB    MAR");
        System.out.println("--------------------------------");
       
        // Display ticket sales for each movie
        //https://www.w3schools.com/java/java_arrays_loop.asp used to help with looping through arrays
        for (int i = 0; i < movies.length; i++) {
            System.out.printf("%-10s", movies[i]);
            int movieTotal = movieTickets.TotalMovieSales(ticketSales[i]);
            totalSales[i] = movieTotal;
            for (int sales : ticketSales[i]) {
                System.out.printf("%7d", sales);
            }
            System.out.println();
            System.out.printf("Total movie ticket sales for %s: %d%n", movies[i], movieTotal);
        }
       
        // Determine and display the top-performing movie
        String topMovie = movieTickets.TopMovie(movies, totalSales);
        System.out.printf("Top performing movie: %s%n", topMovie);
    }
}

