/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package movieticketssales;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class IMovieTicketsTest {
    
    public IMovieTicketsTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of TotalMovieSales method, of class IMovieTickets.
     */
    @Test
    public void testTotalMovieSales() {
        System.out.println("TotalMovieSales");
        int[] movieTicketSales = null;
        IMovieTickets instance = new IMovieTicketsImpl();
        int expResult = 0;
        int result = instance.TotalMovieSales(movieTicketSales);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of TopMovie method, of class IMovieTickets.
     */
    @Test
    public void testTopMovie() {
        System.out.println("TopMovie");
        String[] movies = null;
        int[] totalSales = null;
        IMovieTickets instance = new IMovieTicketsImpl();
        String expResult = "";
        String result = instance.TopMovie(movies, totalSales);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class IMovieTicketsImpl implements IMovieTickets {

        public int TotalMovieSales(int[] movieTicketSales) {
            return 0;
        }

        public String TopMovie(String[] movies, int[] totalSales) {
            return "";
        }
    }
    
}
