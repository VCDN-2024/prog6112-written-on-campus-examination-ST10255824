/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package movieticketssales;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MovieTicketsSalesTest {

    @Test
    public void testCalculateTotalSales_ReturnsExpectedTotalSales() {
        MovieTickets movieTickets = new MovieTickets();
        int[] sales = {3000, 1600, 1700};
        int expectedTotal = 6300;
        assertEquals(expectedTotal, movieTickets.TotalMovieSales(sales));
    }
   
    @Test
    public void testTopMovieSales_ReturnsTopMovie() {
        MovieTickets movieTickets = new MovieTickets();
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totalSales = {6300, 6300}; // Adjust these values to reflect actual sales
        String expectedTopMovie = "Oppenheimer";
        assertEquals(expectedTopMovie, movieTickets.TopMovie(movies, totalSales));
    }
}
