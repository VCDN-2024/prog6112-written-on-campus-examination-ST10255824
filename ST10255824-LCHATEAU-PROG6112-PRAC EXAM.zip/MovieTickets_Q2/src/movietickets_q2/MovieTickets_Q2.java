/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package movietickets_q2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;

// IMovieTickets interface
interface IMovieTickets {
    double calculateTotalTicketPrice(int numberOfTickets, double ticketPrice);
    boolean validateData(MovieTicketData movieTicketData);
}

// MovieTicketData helper class
class MovieTicketData {
    private String movieName;
    private int numberOfTickets;
    private double ticketPrice;

    public MovieTicketData(String movieName, int numberOfTickets, double ticketPrice) {
        this.movieName = movieName;
        this.numberOfTickets = numberOfTickets;
        this.ticketPrice = ticketPrice;
    }

    public String getMovieName() {
        return movieName;
    }

    public int getNumberOfTickets() {
        return numberOfTickets;
    }

    public double getTicketPrice() {
        return ticketPrice;
    }
}

// MovieTickets class implementing the IMovieTickets interface
class MovieTickets implements IMovieTickets {
    private static final double VAT_RATE = 0.14;

    @Override
    public double calculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        double totalPrice = numberOfTickets * ticketPrice;
        return totalPrice + (totalPrice * VAT_RATE);
    }

    @Override
    public boolean validateData(MovieTicketData movieTicketData) {
        if (movieTicketData.getMovieName() == null || movieTicketData.getMovieName().isEmpty()) {
            return false;
        }
        if (movieTicketData.getNumberOfTickets() <= 0) {
            return false;
        }
        if (movieTicketData.getTicketPrice() <= 0) {
            return false;
        }
        return true;
    }
}

// Main application class
//https://www.guru99.com/java-swing-gui.html used to help code up GUI
//https://www3.ntu.edu.sg/home/ehchua/programming/java/j4a_gui.html used to help code up GUI
public class MovieTickets_Q2 extends JFrame {
    private JComboBox<String> movieComboBox;
    private JTextField ticketNumberField;
    private JTextField ticketPriceField;
    private JTextArea reportArea;
    private MovieTickets movieTickets;

    public MovieTickets_Q2() {
        movieTickets = new MovieTickets();

        // Set up frame
        setTitle("Movie Tickets");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel for input fields
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2, 5, 5));

        // Movie selection
        panel.add(new JLabel("Movie:"));
        movieComboBox = new JComboBox<>(new String[]{"Napoleon", "Oppenheimer", "Damsel"});
        panel.add(movieComboBox);

        // Number of tickets
        panel.add(new JLabel("Number of Tickets:"));
        ticketNumberField = new JTextField();
        panel.add(ticketNumberField);

        // Ticket price
        panel.add(new JLabel("Ticket Price:"));
        ticketPriceField = new JTextField();
        panel.add(ticketPriceField);

        // Report area
        panel.add(new JLabel("Ticket Report:"));
        reportArea = new JTextArea(5, 20);
        reportArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(reportArea);
        panel.add(scrollPane);

        add(panel, BorderLayout.CENTER);

        // Menu
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitMenuItem);
        menuBar.add(fileMenu);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processMenuItem = new JMenuItem("Process");
        processMenuItem.addActionListener(new ProcessActionListener());
        toolsMenu.add(processMenuItem);

        JMenuItem clearMenuItem = new JMenuItem("Clear");
        clearMenuItem.addActionListener(e -> clearForm());
        toolsMenu.add(clearMenuItem);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);
    }

    private class ProcessActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                String movieName = (String) movieComboBox.getSelectedItem();
                int numberOfTickets = Integer.parseInt(ticketNumberField.getText());
                double ticketPrice = Double.parseDouble(ticketPriceField.getText());

                MovieTicketData movieTicketData = new MovieTicketData(movieName, numberOfTickets, ticketPrice);

                if (!movieTickets.validateData(movieTicketData)) {
                    JOptionPane.showMessageDialog(MovieTickets_Q2.this,
                            "Invalid data. Please check the input fields.",
                            "Validation Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                double totalWithVAT = movieTickets.calculateTotalTicketPrice(numberOfTickets, ticketPrice);

                String report = "MOVIE NAME: " + movieName + "\n" +
                        "MOVIE TICKET PRICE: R " + String.format("%.2f", ticketPrice) + "\n" +
                        "NUMBER OF TICKETS: " + numberOfTickets + "\n" +
                        "TOTAL TICKET PRICE: R " + String.format("%.2f", totalWithVAT);

                reportArea.setText(report);
                saveReportToFile(report);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(MovieTickets_Q2.this,
                        "Please enter valid numbers for tickets and price.",
                        "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        private void saveReportToFile(String report) {
            try (FileWriter writer = new FileWriter("report.txt")) {
                writer.write("MOVIE TICKET REPORT\n");
                writer.write(report);
                writer.write("\n***\n");
                JOptionPane.showMessageDialog(MovieTickets_Q2.this,
                        "Report saved to report.txt",
                        "File Saved", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(MovieTickets_Q2.this,
                        "Error saving report to file.",
                        "File Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void clearForm() {
        movieComboBox.setSelectedIndex(0);
        ticketNumberField.setText("");
        ticketPriceField.setText("");
        reportArea.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MovieTickets_Q2 app = new MovieTickets_Q2();
            app.setVisible(true);
        });
    }
}

